package dev.phantom.mixin;

import dev.phantom.PhantomClient;
import dev.phantom.module.modules.movement.Timer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Sets RenderTickCounter.ticksPerSecond each render frame to implement Timer.
 *
 * Vanilla ticksPerSecond = 20.0f. Timer.multiplier scales it directly.
 * e.g. multiplier 1.05 -> ticksPerSecond 21.0 -> 5% faster tick progression.
 *
 * Reset to 20.0f when Timer is disabled so no residual speed remains.
 */
@Mixin(GameRenderer.class)
public class MixinGameRenderer {

    private static final float VANILLA_TPS = 20.0f;

    @Inject(method = "render", at = @At("HEAD"))
    private void onRender(float tickDelta, long startTime, boolean tick, CallbackInfo ci) {
        Timer timerMod = PhantomClient.modules.get(Timer.class);
        if (timerMod == null) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        // TimerAccessor -> getRenderTickCounter() -> RenderTickCounterAccessor -> setTicksPerSecond
        TimerAccessor mcAcc = (TimerAccessor) mc;
        RenderTickCounter counter = mcAcc.getRenderTickCounter();
        if (counter == null) return;

        RenderTickCounterAccessor counterAcc = (RenderTickCounterAccessor) counter;
        counterAcc.setTicksPerSecond(VANILLA_TPS * timerMod.getMultiplier());
    }
}
