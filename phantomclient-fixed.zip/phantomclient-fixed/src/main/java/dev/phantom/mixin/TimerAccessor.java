package dev.phantom.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes MinecraftClient.renderTickCounter for the Timer module.
 *
 * In 1.21.1 the old Timer class with timerSpeed was replaced by
 * RenderTickCounter. This accessor gets the counter instance;
 * RenderTickCounterAccessor then exposes its ticksPerSecond field.
 */
@Mixin(MinecraftClient.class)
public interface TimerAccessor {
    @Accessor("renderTickCounter")
    RenderTickCounter getRenderTickCounter();
}
