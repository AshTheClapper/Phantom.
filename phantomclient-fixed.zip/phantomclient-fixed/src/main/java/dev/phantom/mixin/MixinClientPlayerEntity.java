package dev.phantom.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Reserved for future client-side player patches.
 *
 * Reach is handled via EntityAttributes.PLAYER_ATTACK_RANGE modifiers
 * in Reach.java -- no mixin needed on the player entity for that in 1.21.1.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class MixinClientPlayerEntity {
    // intentionally empty -- kept in mixin list for future use
}
