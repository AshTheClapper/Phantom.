package dev.phantom.mixin;

import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(EntityVelocityUpdateS2CPacket.class)
public interface VelocityPacketAccessor {
    @Accessor("velocityX") int getVelocityX();
    @Accessor("velocityY") int getVelocityY();
    @Accessor("velocityZ") int getVelocityZ();
    @Mutable @Accessor("velocityX") void setVelocityX(int v);
    @Mutable @Accessor("velocityY") void setVelocityY(int v);
    @Mutable @Accessor("velocityZ") void setVelocityZ(int v);
}
