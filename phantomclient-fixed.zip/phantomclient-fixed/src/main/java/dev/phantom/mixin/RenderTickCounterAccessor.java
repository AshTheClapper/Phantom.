package dev.phantom.mixin;

import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes RenderTickCounter.ticksPerSecond for Timer manipulation.
 *
 * Vanilla default: 20.0 (20 ticks/second).
 * Setting to 21.0 speeds all client-side physics by 5%.
 * Setting to 19.0 slows them by 5%.
 *
 * Field name per yarn 1.21.1+build.3 mappings.
 */
@Mixin(RenderTickCounter.class)
public interface RenderTickCounterAccessor {
    @Accessor("ticksPerSecond")
    float getTicksPerSecond();

    @Mutable
    @Accessor("ticksPerSecond")
    void setTicksPerSecond(float v);
}
