package dev.phantom.mixin;

import dev.phantom.PhantomClient;
import dev.phantom.module.modules.combat.Velocity;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.client.MinecraftClient;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts EntityVelocityUpdateS2CPacket before application to scale knockback.
 *
 * Method descriptor fix for 1.21.1:
 *   handlePacket(Packet<T>, T (PacketListener), @Nullable PacketCallbacks)
 * The previous version was missing the PacketListener parameter -- mixin
 * would silently fail to apply, leaving velocity unmodified.
 */
@Mixin(ClientConnection.class)
public class MixinClientConnection {

    @Inject(
        method = "handlePacket",
        at = @At("HEAD")
    )
    private static <T extends PacketListener> void onHandlePacket(
            Packet<T> packet,
            T listener,
            @Nullable PacketCallbacks callbacks,
            CallbackInfo ci) {

        if (!(packet instanceof EntityVelocityUpdateS2CPacket p)) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (p.getEntityId() != mc.player.getId()) return;

        Velocity vel = PhantomClient.modules.get(Velocity.class);
        if (vel == null || !vel.isEnabled()) return;

        double hMult = vel.rollHorizontal();
        double vMult = vel.getVertical();

        VelocityPacketAccessor acc = (VelocityPacketAccessor) p;
        acc.setVelocityX((int) (acc.getVelocityX() * hMult));
        acc.setVelocityY((int) (acc.getVelocityY() * vMult));
        acc.setVelocityZ((int) (acc.getVelocityZ() * hMult));
    }
}
