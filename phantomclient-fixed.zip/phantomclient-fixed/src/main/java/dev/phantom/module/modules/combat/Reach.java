package dev.phantom.module.modules.combat;

import dev.phantom.module.Module;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

/**
 * Reach -- extends attack distance above vanilla 3.5 (1.21.1 attribute base).
 *
 * Uses the EntityAttributes.PLAYER_ATTACK_RANGE attribute added in 1.21,
 * replacing the old hardcoded 3.0 distance. A temporary ADD_VALUE modifier
 * is rerolled each tick to maintain gaussian variance across attacks.
 *
 * Defaults adjusted for 1.21.1 baseline:
 *   vanilla = 3.5 blocks
 *   Mean 3.7, Sigma 0.03 = ~0.2 block extension with jitter
 *
 * The modifier is removed cleanly on disable -- no attribute leak.
 */
public class Reach extends Module {

    /** Stable identifier: attribute system requires a unique Identifier per modifier. */
    private static final Identifier REACH_MODIFIER_ID =
            Identifier.of("phantomclient", "reach_bonus");

    private final FloatSetting reachMean;
    private final FloatSetting reachSigma;

    private static final Random RNG = new Random();

    /** Vanilla base reach in 1.21.1. */
    private static final double VANILLA_REACH = 3.5;

    public Reach() {
        super("Reach", Category.COMBAT, GLFW.GLFW_KEY_R);
        reachMean  = range("Mean",  3.7f,  3.5f, 5.0f);
        reachSigma = range("Sigma", 0.03f, 0.0f, 0.15f);
    }

    @Override
    public void onEnable() {
        applyModifier();
    }

    @Override
    public void onDisable() {
        removeModifier();
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        // Reroll gaussian each tick -- since attacks fire once per cooldown,
        // this gives per-attack variance without a separate hook.
        applyModifier();
    }

    /* ── attribute modifier helpers ─────────────────────────────────── */

    private void applyModifier() {
        if (mc.player == null) return;
        var attr = mc.player.getAttributeInstance(EntityAttributes.PLAYER_ATTACK_RANGE);
        if (attr == null) return;

        // Remove previous modifier before adding new rolled value
        attr.removeModifier(REACH_MODIFIER_ID);

        double bonus = rollBonus();
        if (bonus <= 0) return;

        attr.addTemporaryModifier(new EntityAttributeModifier(
                REACH_MODIFIER_ID,
                bonus,
                EntityAttributeModifier.Operation.ADD_VALUE
        ));
    }

    private void removeModifier() {
        if (mc.player == null) return;
        var attr = mc.player.getAttributeInstance(EntityAttributes.PLAYER_ATTACK_RANGE);
        if (attr == null) return;
        attr.removeModifier(REACH_MODIFIER_ID);
    }

    /**
     * Returns the ADD_VALUE bonus above vanilla reach.
     * Gaussian-rolled: N(mean - VANILLA, sigma). Clamped to [0, mean - VANILLA + 0.2].
     */
    private double rollBonus() {
        double target = reachMean.get() - VANILLA_REACH;
        double v      = target + RNG.nextGaussian() * reachSigma.get();
        return Math.max(0.0, Math.min(target + 0.2, v));
    }

    /** Convenience for external callers (KillAura range display, etc.). */
    public double getEffectiveReach() {
        return isEnabled() ? reachMean.get() : VANILLA_REACH;
    }
}
