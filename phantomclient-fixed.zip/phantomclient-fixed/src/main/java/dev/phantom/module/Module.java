package dev.phantom.module;

import net.minecraft.client.MinecraftClient;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Base class for all PhantomClient modules.
 * Each module has: name, category, keybind, enabled state, settings map.
 */
public abstract class Module {

    public enum Category { COMBAT, MOVEMENT, RENDER, MISC }

    protected final MinecraftClient mc = MinecraftClient.getInstance();

    private final String   name;
    private final Category category;
    private       int      keybind;   // GLFW key code, -1 = unbound
    private       boolean  enabled;

    /** Settings: name -> Setting<?> */
    protected final Map<String, Setting<?>> settings = new LinkedHashMap<>();

    public Module(String name, Category category, int keybind) {
        this.name     = name;
        this.category = category;
        this.keybind  = keybind;
        this.enabled  = false;
    }

    /* ── lifecycle ─────────────────────────────────────────────────── */

    public void onEnable()  {}
    public void onDisable() {}
    public void onTick()    {}

    /* ── toggle ────────────────────────────────────────────────────── */

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable();
        else         onDisable();
    }

    public void setEnabled(boolean v) {
        if (v != enabled) toggle();
    }

    /* ── settings helpers ───────────────────────────────────────────── */

    protected BoolSetting  bool(String name, boolean def) {
        BoolSetting s = new BoolSetting(name, def);
        settings.put(name, s);
        return s;
    }

    protected FloatSetting range(String name, float def, float min, float max) {
        FloatSetting s = new FloatSetting(name, def, min, max);
        settings.put(name, s);
        return s;
    }

    /* ── getters ────────────────────────────────────────────────────── */

    public String   getName()     { return name; }
    public Category getCategory() { return category; }
    public int      getKeybind()  { return keybind; }
    public boolean  isEnabled()   { return enabled; }
    public Map<String, Setting<?>> getSettings() { return settings; }

    public void setKeybind(int key) { this.keybind = key; }

    /* ══ inner setting types ════════════════════════════════════════ */

    public abstract static class Setting<T> {
        private final String name;
        protected T value;
        public Setting(String name, T def) { this.name = name; this.value = def; }
        public String getName()  { return name; }
        public T      getValue() { return value; }
        public void   setValue(T v) { this.value = v; }
    }

    public static class BoolSetting extends Setting<Boolean> {
        public BoolSetting(String name, boolean def) { super(name, def); }
        public boolean get() { return value; }
        public void    toggle() { value = !value; }
    }

    public static class FloatSetting extends Setting<Float> {
        private final float min, max;
        public FloatSetting(String name, float def, float min, float max) {
            super(name, def);
            this.min = min; this.max = max;
        }
        public float get()            { return value; }
        public float getMin()         { return min; }
        public float getMax()         { return max; }
        public void  set(float v)     { value = Math.max(min, Math.min(max, v)); }
    }
}
