package dev.phantom.module;

import dev.phantom.module.modules.combat.*;
import dev.phantom.module.modules.movement.Timer;

import java.util.*;

public class ModuleManager {

    private final List<Module>        modules = new ArrayList<>();
    private final Map<Integer, Module> keyMap  = new HashMap<>();

    /* ── registration ───────────────────────────────────────────────── */

    public void registerAll() {
        register(new Reach());
        register(new Velocity());
        register(new AimAssist());
        register(new AutoCrit());
        register(new KillAura());
        register(new Timer());
    }

    private void register(Module m) {
        modules.add(m);
        if (m.getKeybind() != -1) keyMap.put(m.getKeybind(), m);
    }

    /* ── tick ───────────────────────────────────────────────────────── */

    public void onTick() {
        for (Module m : modules) {
            if (m.isEnabled()) m.onTick();
        }
    }

    /* ── keybind dispatch ───────────────────────────────────────────── */

    public void onKeyPress(int keyCode) {
        Module m = keyMap.get(keyCode);
        if (m != null) m.toggle();
    }

    /* ── queries ────────────────────────────────────────────────────── */

    public List<Module> getModules() { return Collections.unmodifiableList(modules); }

    public <T extends Module> T get(Class<T> cls) {
        for (Module m : modules) {
            if (cls.isInstance(m)) return cls.cast(m);
        }
        return null;
    }

    public List<Module> getByCategory(Module.Category cat) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == cat) out.add(m);
        }
        return out;
    }
}
