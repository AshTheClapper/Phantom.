package dev.phantom.module.modules.combat;

import dev.phantom.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import org.lwjgl.glfw.GLFW;

/**
 * AutoCrit -- sends fake fall-state packets before each attack,
 * tricking the server into registering a critical hit.
 *
 * In 1.9+ a crit requires:
 *   1. Player is falling (velocity.y < 0)
 *   2. Player is not on ground
 *   3. Not in water, not riding, not blind
 *
 * Implementation sends two position packets:
 *   - Packet A: onGround=false, y+0.11 (small hop)
 *   - Packet B: onGround=false, y+0.00 (peak)
 * Then the actual attack fires with the server believing we are falling.
 *
 * Ground check: if player is actually airborne already, skip injection
 * (no need to fake what is already true -- avoids double-packet anomaly).
 */
public class AutoCrit extends Module {

    private final BoolSetting groundOnly;

    public AutoCrit() {
        super("AutoCrit", Category.COMBAT, GLFW.GLFW_KEY_C);
        groundOnly = bool("GroundOnly", true);
    }

    /**
     * Call this immediately before sending an attack packet.
     * Injects fall packets if conditions are met.
     */
    public void injectBeforeAttack() {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.getNetworkHandler() == null) return;

        // skip if already in the air -- crit will land naturally
        if (!mc.player.isOnGround()) return;
        // skip if ground-only is off (always inject)
        // groundOnly=true means only inject when on ground, which is always here
        // since we already checked isOnGround above

        double x = mc.player.getX();
        double y = mc.player.getY();
        double z = mc.player.getZ();

        // tiny hop sequence -- just enough to set falling state server-side
        mc.getNetworkHandler().sendPacket(
                new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0625, z, false, false));
        mc.getNetworkHandler().sendPacket(
                new PlayerMoveC2SPacket.PositionAndOnGround(x, y,          z, false, false));
    }
}
