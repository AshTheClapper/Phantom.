package dev.phantom.module.modules.combat;

import dev.phantom.PhantomClient;
import dev.phantom.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.item.AxeItem;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

/**
 * KillAura -- attacks the nearest player once per full attack cooldown.
 *
 * 1.9+ mode: fires ONLY at cooldown >= 100% to avoid partial hits.
 * Partial hits deal reduced damage and have a distinct packet timing
 * signature that ACs flag as "attack spam."
 *
 * Miss chance: configurable % of eligible attacks are skipped,
 * inserting human-like misses into the attack log.
 *
 * Weapon check: optionally only fires when holding a sword or axe.
 */
public class KillAura extends Module {

    private final FloatSetting range;
    private final FloatSetting missChance;
    private final BoolSetting  weaponOnly;
    private final BoolSetting  rotateToTarget;

    private static final Random RNG = new Random();

    public KillAura() {
        super("KillAura", Category.COMBAT, GLFW.GLFW_KEY_K);
        range          = range("Range",    3.15f, 3.0f, 4.0f);
        missChance     = range("Miss%",    10f,   0f,   40f);
        weaponOnly     = bool("WeaponOnly",  true);
        rotateToTarget = bool("SilentRotate", true);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;

        // weapon check
        if (weaponOnly.get()) {
            var held = mc.player.getMainHandStack().getItem();
            if (!(held instanceof SwordItem) && !(held instanceof AxeItem)) return;
        }

        // cooldown check -- 1.0 = fully charged
        float cooldown = mc.player.getAttackCooldownProgress(0f);
        if (cooldown < 1.0f) return;

        // miss chance
        if (RNG.nextFloat() * 100f < missChance.get()) return;

        // find target
        PlayerEntity target = findNearest(mc);
        if (target == null) return;

        // autocrit injection
        AutoCrit ac = PhantomClient.modules.get(AutoCrit.class);
        if (ac != null) ac.injectBeforeAttack();

        // attack
        mc.interactionManager.attackEntity(mc.player, target);
        mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
    }

    private PlayerEntity findNearest(MinecraftClient mc) {
        PlayerEntity best     = null;
        double       bestDist = range.get();

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            if (p.isDead() || p.isSpectator()) continue;
            double d = mc.player.distanceTo(p);
            if (d < bestDist) { bestDist = d; best = p; }
        }
        return best;
    }
}
