package dev.phantom.module.modules.combat;

import dev.phantom.PhantomClient;
import dev.phantom.module.Module;
import dev.phantom.util.RotationUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Optional;
import java.util.Random;

/**
 * AimAssist -- bezier-curve smooth rotation toward the nearest player.
 *
 * Why bezier over linear lerp (Argon's default):
 *   Linear lerp: each tick moves a fixed fraction toward target.
 *   Behaviour is mechanical -- ACs can detect the constant approach rate.
 *
 *   Cubic bezier: acceleration eases in/out, matching how a human
 *   eye tracks a moving target -- fast initial correction that slows
 *   as the cursor nears the target. Detection-resistant.
 *
 * Settings:
 *   FOV     -- only assist within this angle of current look direction
 *   Speed   -- how fast the bezier completes (ticks to reach target)
 *   Chance  -- % chance to assist each tick (adds human variance)
 *   OnClick -- only assist while left mouse is held
 */
public class AimAssist extends Module {

    private final FloatSetting fov;
    private final FloatSetting speed;
    private final FloatSetting chance;
    private final BoolSetting  onLeftClick;
    private final BoolSetting  stopAtTarget;

    private static final Random RNG = new Random();

    /** Bezier progress [0..1] for current target lock. */
    private float bezierT = 0f;
    private float[] startYaw   = {0f};
    private float[] startPitch = {0f};
    private PlayerEntity currentTarget = null;

    public AimAssist() {
        super("AimAssist", Category.COMBAT, GLFW.GLFW_KEY_Z);
        fov          = range("FOV",    65f,  1f,  360f);
        speed        = range("Speed",  8f,   1f,   30f);   // ticks to complete
        chance       = range("Chance", 80f,  1f,  100f);
        onLeftClick  = bool("OnClick", true);
        stopAtTarget = bool("StopAtTarget", true);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (onLeftClick.get() && !isLeftClickHeld(mc)) { bezierT = 0f; return; }
        if (RNG.nextFloat() * 100f > chance.get()) return;

        Optional<PlayerEntity> target = findTarget(mc);
        if (target.isEmpty()) { bezierT = 0f; currentTarget = null; return; }

        PlayerEntity t = target.get();
        if (t != currentTarget) {
            // new target: reset bezier from current look angles
            currentTarget = t;
            bezierT       = 0f;
            startYaw[0]   = mc.player.getYaw();
            startPitch[0] = mc.player.getPitch();
        }

        float[] needed = RotationUtil.getNeededRotations(mc.player, t);
        float   tYaw   = needed[0];
        float   tPitch = needed[1];

        // advance bezier
        bezierT = Math.min(1f, bezierT + (1f / speed.get()));
        float ease = cubicEaseInOut(bezierT);

        float newYaw   = lerpAngle(startYaw[0],   tYaw,   ease);
        float newPitch = lerp(startPitch[0], tPitch, ease);

        if (stopAtTarget.get()) {
            // don't overshoot
            float diffYaw   = angleDiff(mc.player.getYaw(), tYaw);
            float diffPitch = tPitch - mc.player.getPitch();
            if (Math.abs(diffYaw) < 0.5f && Math.abs(diffPitch) < 0.5f) {
                bezierT = 1f;
                return;
            }
        }

        mc.player.setYaw(newYaw);
        mc.player.setPitch(newPitch);
    }

    /* ── target selection ───────────────────────────────────────────── */

    private Optional<PlayerEntity> findTarget(MinecraftClient mc) {
        double maxDist = 6.0;
        float  myYaw   = mc.player.getYaw();
        float  myPitch = mc.player.getPitch();

        PlayerEntity best     = null;
        double       bestDist = Double.MAX_VALUE;

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            if (p.isDead() || p.isSpectator()) continue;

            double dist = mc.player.distanceTo(p);
            if (dist > maxDist) continue;

            float[] ang = RotationUtil.getNeededRotations(mc.player, p);
            float   diff = Math.abs(angleDiff(myYaw, ang[0]));
            if (diff > fov.get() / 2f) continue;

            if (dist < bestDist) { bestDist = dist; best = p; }
        }
        return Optional.ofNullable(best);
    }

    /* ── math helpers ───────────────────────────────────────────────── */

    /** Cubic ease-in-out bezier: slow start, fast middle, slow end. */
    private static float cubicEaseInOut(float t) {
        return t < 0.5f
                ? 4f * t * t * t
                : 1f - (float) Math.pow(-2f * t + 2f, 3) / 2f;
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float lerpAngle(float a, float b, float t) {
        return a + angleDiff(a, b) * t;
    }

    /** Signed shortest-path angle difference in [-180, 180]. */
    private static float angleDiff(float from, float to) {
        float d = ((to - from) % 360f + 540f) % 360f - 180f;
        return d;
    }

    private static boolean isLeftClickHeld(MinecraftClient mc) {
        return GLFW.glfwGetMouseButton(mc.getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    }
}
