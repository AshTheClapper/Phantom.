package dev.phantom.module.modules.movement;

import dev.phantom.module.Module;
import org.lwjgl.glfw.GLFW;

/**
 * Timer -- manipulates the game's tick rate multiplier.
 *
 * Vanilla tick rate: 20 tps = multiplier 1.0
 * Values above 1.0 speed up movement, attack speed, and projectiles.
 * Values below 1.0 slow them down.
 *
 * Safe range: 0.97–1.03 (invisible to most ACs)
 * Noticeable: 1.05+ (Grim will flag movement speed anomaly)
 *
 * Applied via MixinGameRenderer which patches the timerSpeed field
 * on MinecraftClient each frame.
 */
public class Timer extends Module {

    private final FloatSetting timerSpeed;

    public Timer() {
        super("Timer", Category.MOVEMENT, GLFW.GLFW_KEY_T);
        timerSpeed = range("Speed", 1.0f, 0.5f, 2.0f);
    }

    /** Returns the current timer multiplier. 1.0 = vanilla. */
    public float getMultiplier() {
        return isEnabled() ? timerSpeed.get() : 1.0f;
    }
}
