package dev.phantom.module.modules.combat;

import dev.phantom.module.Module;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

/**
 * Velocity -- reduces incoming knockback by multiplying the velocity
 * delta applied on EntityVelocityUpdateS2CPacket and
 * PlayerPositionLookS2CPacket.
 *
 * Per-hit randomization: horizontal multiplier drawn from
 * [hMin, hMax] each time. Avoids the flat-multiplier statistical
 * signature that Vulcan's velocity variance check catches.
 *
 * Safe config:
 *   hMin=0.82, hMax=0.95, vertical=1.0
 * Aggressive (may flag Grim):
 *   hMin=0.6, hMax=0.8
 */
public class Velocity extends Module {

    private final FloatSetting hMin;
    private final FloatSetting hMax;
    private final FloatSetting vertical;

    private static final Random RNG = new Random();

    public Velocity() {
        super("Velocity", Category.COMBAT, GLFW.GLFW_KEY_V);
        hMin     = range("H-Min",    0.82f, 0.0f, 1.0f);
        hMax     = range("H-Max",    0.95f, 0.0f, 1.0f);
        vertical = range("Vertical", 1.0f,  0.0f, 1.0f);
    }

    /** Returns horizontal multiplier for this knockback event. */
    public double rollHorizontal() {
        if (!isEnabled()) return 1.0;
        float lo = hMin.get(), hi = hMax.get();
        if (lo > hi) { float t = lo; lo = hi; hi = t; }
        return lo + RNG.nextFloat() * (hi - lo);
    }

    public double getVertical() {
        return isEnabled() ? vertical.get() : 1.0;
    }
}
