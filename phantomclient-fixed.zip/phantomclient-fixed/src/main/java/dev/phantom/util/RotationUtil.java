package dev.phantom.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class RotationUtil {

    private RotationUtil() {}

    /**
     * Returns [yaw, pitch] needed for {@code from} to look at
     * the chest of {@code to}.
     *
     * Chest offset: target eye height * 0.6 below eye level.
     */
    public static float[] getNeededRotations(PlayerEntity from, Entity to) {
        Vec3d src = from.getEyePos();
        Vec3d dst = to.getEyePos().subtract(0, to.getEyeHeight(to.getPose()) * 0.4, 0);

        double dx = dst.x - src.x;
        double dy = dst.y - src.y;
        double dz = dst.z - src.z;

        double dist = Math.sqrt(dx * dx + dz * dz);

        float yaw   = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));

        return new float[]{ yaw, pitch };
    }

    /** Wrap yaw to [-180, 180]. */
    public static float wrapYaw(float yaw) {
        yaw %= 360f;
        if (yaw > 180f)  yaw -= 360f;
        if (yaw < -180f) yaw += 360f;
        return yaw;
    }
}
