package dev.phantom.config;

import com.google.gson.*;
import dev.phantom.PhantomClient;
import dev.phantom.module.Module;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.*;

/**
 * Saves/loads module enabled states and float/bool settings to JSON.
 *
 * Config file: .minecraft/config/phantomclient.json
 *
 * Format:
 * {
 *   "Reach": {
 *     "enabled": false,
 *     "settings": { "Mean": 3.15, "Sigma": 0.03 }
 *   },
 *   ...
 * }
 */
public class ConfigManager {

    private final Path configPath;
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public ConfigManager() {
        configPath = FabricLoader.getInstance()
                .getConfigDir()
                .resolve("phantomclient.json");
    }

    public void save() {
        JsonObject root = new JsonObject();
        for (Module m : PhantomClient.modules.getModules()) {
            JsonObject entry    = new JsonObject();
            JsonObject settings = new JsonObject();

            entry.addProperty("enabled", m.isEnabled());

            for (var kv : m.getSettings().entrySet()) {
                Module.Setting<?> s = kv.getValue();
                if (s instanceof Module.FloatSetting fs) {
                    settings.addProperty(kv.getKey(), fs.get());
                } else if (s instanceof Module.BoolSetting bs) {
                    settings.addProperty(kv.getKey(), bs.get());
                }
            }
            entry.add("settings", settings);
            root.add(m.getName(), entry);
        }

        try (Writer w = Files.newBufferedWriter(configPath)) {
            gson.toJson(root, w);
        } catch (IOException e) {
            PhantomClient.LOGGER.warn("Failed to save config: {}", e.getMessage());
        }
    }

    public void load() {
        if (!Files.exists(configPath)) return;

        try (Reader r = Files.newBufferedReader(configPath)) {
            JsonObject root = gson.fromJson(r, JsonObject.class);
            if (root == null) return;

            for (Module m : PhantomClient.modules.getModules()) {
                JsonElement el = root.get(m.getName());
                if (el == null || !el.isJsonObject()) continue;
                JsonObject entry = el.getAsJsonObject();

                if (entry.has("enabled") && entry.get("enabled").getAsBoolean() != m.isEnabled()) {
                    m.toggle();
                }

                JsonElement settingsEl = entry.get("settings");
                if (settingsEl == null || !settingsEl.isJsonObject()) continue;
                JsonObject settings = settingsEl.getAsJsonObject();

                for (var kv : m.getSettings().entrySet()) {
                    JsonElement sv = settings.get(kv.getKey());
                    if (sv == null) continue;
                    Module.Setting<?> s = kv.getValue();
                    if (s instanceof Module.FloatSetting fs) {
                        fs.set(sv.getAsFloat());
                    } else if (s instanceof Module.BoolSetting bs) {
                        if (bs.get() != sv.getAsBoolean()) bs.toggle();
                    }
                }
            }
        } catch (IOException | JsonParseException e) {
            PhantomClient.LOGGER.warn("Failed to load config: {}", e.getMessage());
        }
    }
}
