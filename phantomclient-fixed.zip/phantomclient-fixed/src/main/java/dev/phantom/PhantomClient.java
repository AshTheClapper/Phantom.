package dev.phantom;

import dev.phantom.config.ConfigManager;
import dev.phantom.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PhantomClient implements ClientModInitializer {

    public static final String NAME    = "PhantomClient";
    public static final String VERSION = "1.0.0";
    public static final Logger LOGGER  = LoggerFactory.getLogger(NAME);

    public static PhantomClient    INSTANCE;
    public static ModuleManager    modules;
    public static ConfigManager    config;
    public static MinecraftClient  mc;

    @Override
    public void onInitializeClient() {
        INSTANCE = this;
        mc       = MinecraftClient.getInstance();
        modules  = new ModuleManager();
        config   = new ConfigManager();

        modules.registerAll();
        config.load();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;
            modules.onTick();
        });

        LOGGER.info("{} {} initialized -- {} modules loaded",
                NAME, VERSION, modules.getModules().size());
    }
}
