# PhantomClient 1.21.1

Ghost client for 1.9+ PvP. Fabric-based, drops into MojoLauncher mods folder.

## Build

```bash
./gradlew build
# output: build/libs/phantomclient-1.0.0.jar
```

Java 21 required.

## Install (MojoLauncher)

1. Build the jar or grab from releases
2. Drop into your instance's `mods/` folder
3. Fabric 1.21.1 must be installed on the instance
4. Launch

## Keybinds

No GUI. All toggles are direct keybinds only.

| Key | Action           |
|-----|------------------|
| R   | Toggle Reach     |
| V   | Toggle Velocity  |
| Z   | Toggle AimAssist |
| C   | Toggle AutoCrit  |
| K   | Toggle KillAura  |
| T   | Toggle Timer     |

## Modules

### Reach
Extends attack distance. Gaussian jitter per hit avoids flat-reach AC signatures.
- **Mean**: center reach value (default 3.15)
- **Sigma**: jitter amount (default 0.03)

### Velocity
Reduces incoming knockback. Per-hit randomized horizontal multiplier.
- **H-Min / H-Max**: horizontal multiplier range (default 0.82–0.95)
- **Vertical**: vertical multiplier (default 1.0, keep at 1.0)

### AimAssist
Bezier-curve smooth rotation toward nearest player in FOV.
- **FOV**: angle cone to assist within (default 65°)
- **Speed**: ticks to complete bezier (default 8)
- **Chance**: % chance to assist each tick (default 80%)
- **OnClick**: only assist while left mouse held (default ON)

### AutoCrit
Sends fake fall packets before each attack for guaranteed crits.
Works in 1.9+ where crits require falling state.

### KillAura
Attacks nearest player when attack cooldown is 100%.
- **Range**: attack range (default 3.15)
- **Miss%**: chance to skip an eligible attack (default 10%)
- **WeaponOnly**: only attack when holding sword/axe (default ON)

### Timer
Multiplies game tick speed.
- **Speed**: multiplier (default 1.0, safe range 0.97–1.03)

## Config

Saved to `.minecraft/config/phantomclient.json` on close.
Auto-loads on startup.

## What makes this better than Argon

- **AimAssist**: cubic bezier easing vs Argon's linear lerp. Human eye tracks with ease-in/out. Detection resistant.
- **Velocity**: per-hit randomized horizontal multiplier vs Argon's flat multiplier. Defeats variance histogram checks.
- **Reach**: gaussian jitter per attack vs fixed reach. No statistical fingerprint.
- **AutoCrit**: ground state detection prevents double-packet anomaly.
- **Config**: full JSON persistence, auto-load on startup.
